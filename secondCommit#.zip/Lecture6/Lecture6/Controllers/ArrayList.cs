﻿namespace Lecture6.Controllers
{
    internal class ArrayList<T>
    {
        public ArrayList()
        {
        }
    }
}