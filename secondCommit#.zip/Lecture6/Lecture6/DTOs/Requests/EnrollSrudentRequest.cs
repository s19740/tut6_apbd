﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lecture6.DTOs.Request
{
    public class EnrollSrudentRequest
    {
        [RegularExpression("^s((1[0-9]{0,4})|([1-9][0-9]{0,3})|20000)$")]
        [Required]
        [MaxLength(100)]
        public string IndexNumber { get; set; }

        [Required]
        [MaxLength(100)]
        public String FirstName { get; set; }

        [Required]
        [MaxLength(100)]
        public String LastName { get; set; }

        [Required]
        public String Birthdate { get; set; }

        [Required]
        public string Studies { get; set; }
    }
}
