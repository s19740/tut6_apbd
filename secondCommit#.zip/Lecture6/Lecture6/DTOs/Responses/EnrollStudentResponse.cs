﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lecture6.DTOs.Response
{
    public class EnrollStudentResponse
    {
      
        public string LastNane { get; set; }

        public int semester { get; set; }
    }
}
