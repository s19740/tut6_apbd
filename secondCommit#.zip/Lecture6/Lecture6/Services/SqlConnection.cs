﻿namespace Lecture6.Services
{
    internal class SqlConnection
    {
        public SqlConnection()
        {
        }
    }
}