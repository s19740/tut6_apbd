﻿using Lecture6.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Lecture6.Services
{
    public class SqlServerDbService : IDbService
    {    private string ConnString = "Data Source=db-mssql;Initial Catalog=s19740;Integrated Security=True;MultipleActiveResultSets=True";
    
        public Student GetStudentbyIndex(string index)
        {
            using (SqlConnection con =new SqlConnection(ConnString))
            using (SqlCommand com =new SqlCommand()){
                Student student = new Student();
              
                com.Connection = con;
                com.CommandText = " Select * from  student s join Enrollment e on s.IdEnrollment=e.IdEnrollment Join Studies st on st.IdStudy=e.IdStudy where s.IndexNumber =@index;";
                com.Parameters.AddWithValue("index", index);
                con.Open();

                var dr = com.ExecuteReader();
                if (dr.Read())
                {
                    student.IndexNumber = dr["IndexNumber"].ToString();
                    student.FirstName = dr["FirstName"].ToString();
                    student.LastName = dr["LastName"].ToString();
                    student.BirthDate = DateTime.Parse(dr["BirthDate"].ToString());
                    student.studies = dr["Name"].ToString();
                }else
                {
                    return null;
                }

                return student;


            }
        }
        //public Student GetStudentByIndex(string index)
        //{
        //    SqlConnection con = new SqlConnection();
          //  SqlCommand com = new SqlCommand();

            //var dr=com.ExecuteReaderAsync(); //...2 sek
         
            
            /*
             *   com.ExecuteReader(new WhenDataWillBeBackCallback(){
             *      //....
             *   });
             * 
             * 
             * 
             * 
             */

            // Concurrency (two or more things happening at the same time)
            // Multithreading - new Thread().Start()... - legacy code
            /* ThreadPool - C# (CLR), Java (JVM)
             * Db - ConnectionPool
             * 
             * 
             * 
             * 
             */
            // Parallel processing
            // Async code

          //  if (index == "s1234")
           // {
             //   return new Student { IdStudent = 1, FirstName = "Andrzej", LastName = "Kowalski" };
           // }

           // return null;
       // }

        public IEnumerable<Student> GetStudents()
        {
            //...
            throw new NotImplementedException();
        }

        public void SaveLogData(string data)
        {
           
        }
    }
}
