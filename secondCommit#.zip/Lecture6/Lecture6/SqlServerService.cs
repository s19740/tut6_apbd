﻿namespace Lecture6
{
    internal class SqlServerService
    {
    }
}